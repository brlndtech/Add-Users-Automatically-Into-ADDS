﻿
Import-Module ActiveDirectory
Import-Module 'Microsoft.PowerShell.Security'

$users = Import-Csv -Delimiter ";" -Path "users-random.csv"


$netbios=Read-Host "Entrez votre NetBIOS"
$domain=Read-Host "Entrez votre nom de domaine"

    New-ADOrganizationalUnit -Name "Sites" -Path "dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "Lyon" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=Lyon,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=Lyon,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=Lyon,ou=Sites,dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "Paris" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=Paris,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=Paris,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=Paris,ou=Sites,dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "Marseille" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=Marseille,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=Marseille,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=Marseille,ou=Sites,dc=$netbios,dc=$domain"


#*******Ajout de chaque utilisateur dans son OU spécifique*******

foreach ($user in $users) {
    
    $name = $user.firstName + " " + $user.lastName
    $fname = $user.firstName
    $lname = $user.lastName
    $login = $user.firstName + "." + $user.lastName
    $Uoffice = $user.office
    $Upassword = $user.password
    $dept = $user.department
  
    If ($user.office -eq "Lyon") {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=Lyon,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 
            "Compta" {$office = "OU=Compta,OU=Services,OU=Lyon,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    ElseIf ($user.office -eq "Paris") {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=Paris,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce
            "Compta" {$office = "OU=Compta,OU=Services,OU=Paris,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    Else {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=Marseille,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce
            "Compta" {$office = "OU=Compta,OU=Services,OU=Marseille,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    
     try {
            New-ADUser -Name $name -SamAccountName $login -UserPrincipalName $login -DisplayName $name -GivenName $fname -Surname $lname -AccountPassword (ConvertTo-SecureString $Upassword -AsPlainText -Force) -City $Uoffice -Path $office -Department $dept -Enabled $true
            echo "Utilisateur ajouté : $name"
          
           
        } catch{
            echo "-Utilisateur non ajouté : $name"
       }   

}
#*********************Groupes Root************************
New-ADGroup -Name G_Info_InterSite -GroupScope Global -GroupCategory Security -Path "ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_InterSite -GroupScope Global -GroupCategory Security -Path "ou=Sites,dc=coud,dc=local"

#*********************Groupes sous Paris************************
New-ADGroup -Name G_Info_Paris -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=Paris,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_Paris -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=Paris,ou=Sites,dc=coud,dc=local"

#*********************Groupes sous Lyon************************
New-ADGroup -Name G_Info_Lyon -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=Lyon,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_Lyon -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=Lyon,ou=Sites,dc=coud,dc=local"

#*********************Groupes sous Marseille************************
New-ADGroup -Name G_Info_Marseille -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=Marseille,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_Marseille -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=Marseille,ou=Sites,dc=coud,dc=local"

foreach ($user in $users){

    $name = $user.firstName + " " + $user.lastName
    $fname = $user.firstName
    $lname = $user.lastName
    $login = $user.firstName + "." + $user.lastName
    $Uoffice = $user.office
    $Upassword = $user.password
    $dept = $user.department 


#********Ajout des utilisateurs de Paris dans leurs groupes********************

    if ($Uoffice -eq "Paris" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity 'G_Info_Paris' -Members $login
        echo "$name a été ajouté au groupe G_Info_Paris"

    }
    elseif ($Uoffice -eq "Paris" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity 'G_Compta_Paris' -Members $login
        echo "$name a été ajouté au groupe G_Compta_Paris"

    }


    #********Ajout des users de Marseille dans leurs groupes********************


    if ($Uoffice -eq "Marseille" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity 'G_Info_Marseille' -Members $login
        echo "$name a été ajouté au groupe G_Info_Marseille"

    }
    elseif ($Uoffice -eq "Marseille" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity 'G_Compta_Marseille' -Members $login
        echo "$name a été ajouté au groupe G_Compta_Marseille"

    }


#********Ajout des users de Lyon dans leurs groupes********************


    if ($Uoffice -eq "Lyon" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity 'G_Info_Lyon' -Members $login
        echo "$name a été ajouté au groupe G_Info_Lyon"

    }
    elseif ($Uoffice -eq "Lyon" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity 'G_Compta_Lyon' -Members $login
        echo "$name a été ajouté au groupe G_Compta_Lyon"

    }

} #Accolade fermante de notre boucle – Fin de la boucle

Add-ADGroupMember -Identity 'G_Info_InterSite' -Members G_Info_Lyon,G_Info_Paris,G_Info_Marseille
Add-ADGroupMember -Identity 'G_Compta_InterSite' -Members G_Compta_Lyon,G_Compta_Paris,G_Compta_Marseille