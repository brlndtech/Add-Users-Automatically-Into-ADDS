﻿######################################################
#        CREATE AND POPULATE YOUR ADDS               #
#          **A script by brlndtech **                #
#      github : https://github.com/brlndtech         #
#            Please RTFM README.md                   #
######################################################

######################################################

# Site géographique de base : Paris,Lyon,Marseille 
# A changer ctrl h dans le csv user-random.csv



Import-Module ActiveDirectory
Import-Module 'Microsoft.PowerShell.Security'

$users = Import-Csv -Delimiter ";" -Path "users-random.csv"


$netbios=Read-Host "Entrez le NetBIOS de votre domaine (ex : entreprise) "
$domain=Read-Host "Entrez votre .tld (ex : .com) "
$site1=Read-Host "Entrez le nom de votre premier site "
$site2=Read-Host "Entrez le nom de votre deuxième site "
$site3=Read-Host "Entrez le nom de votre troisième site "


    New-ADOrganizationalUnit -Name "Sites" -Path "dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "$site1" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=$site1,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=$site1,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=$site1,ou=Sites,dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "$site2" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=$site2,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=$site2,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=$site2,ou=Sites,dc=$netbios,dc=$domain"

    New-ADOrganizationalUnit -Name "$site3" -Path "ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Services" -Path "ou=$site3,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Info" -Path "ou=Services,ou=$site3,ou=Sites,dc=$netbios,dc=$domain"
    New-ADOrganizationalUnit -Name "Compta" -Path "ou=Services,ou=$site3,ou=Sites,dc=$netbios,dc=$domain"


#*******Ajout de chaque utilisateur dans son OU spécifique*******

foreach ($user in $users) {
    
    $name = $user.firstName + " " + $user.lastName
    $fname = $user.firstName
    $lname = $user.lastName
    $login = $user.firstName + "." + $user.lastName
    $Uoffice = $user.office
    $Upassword = $user.password
    $dept = $user.department
  
    If ($user.office -eq "$site1") {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=$site1,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 
            "Compta" {$office = "OU=Compta,OU=Services,OU=$site1,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    ElseIf ($user.office -eq "$site2") {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=$site2,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce
            "Compta" {$office = "OU=Compta,OU=Services,OU=$site2,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    ElseIf ($user.office -eq "$site3") {
        switch($user.department)
        {
            "Info" {$office = "OU=Info,OU=Services,OU=$site3,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce
            "Compta" {$office = "OU=Compta,OU=Services,OU=$site3,OU=Sites,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 

        }
    }
    
     try {
            New-ADUser -Name $name -SamAccountName $login -UserPrincipalName $login -DisplayName $name -GivenName $fname -Surname $lname -AccountPassword (ConvertTo-SecureString $Upassword -AsPlainText -Force) -City $Uoffice -Path $office -Department $dept -Enabled $true
            echo "Utilisateur ajouté : $name"
          
           
        } catch{
            echo "-Utilisateur non ajouté : $name"
       }   

}
#*********************Groupes Root************************
New-ADGroup -Name G_Info_InterSite -GroupScope Global -GroupCategory Security -Path "ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_InterSite -GroupScope Global -GroupCategory Security -Path "ou=Sites,dc=coud,dc=local"

#*********************Groupes sous $site2************************
New-ADGroup -Name G_Info_$site2 -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=$site2,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_$site2 -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=$site2,ou=Sites,dc=coud,dc=local"

#*********************Groupes sous $site1************************
New-ADGroup -Name G_Info_$site1 -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=$site1,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_$site1 -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=$site1,ou=Sites,dc=coud,dc=local"

#*********************Groupes sous $site3************************
New-ADGroup -Name G_Info_$site3 -GroupScope Global -GroupCategory Security -Path "ou=Info,ou=Services,ou=$site3,ou=Sites,dc=coud,dc=local"
New-ADGroup -Name G_Compta_$site3 -GroupScope Global -GroupCategory Security -Path "ou=Compta,ou=Services,ou=$site3,ou=Sites,dc=coud,dc=local"

foreach ($user in $users){

    $name = $user.firstName + " " + $user.lastName
    $fname = $user.firstName
    $lname = $user.lastName
    $login = $user.firstName + "." + $user.lastName
    $Uoffice = $user.office
    $Upassword = $user.password
    $dept = $user.department 


#********Ajout des utilisateurs de $site2 dans leurs groupes********************

    if ($Uoffice -eq "$site2" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity "G_Info_$site2" -Members $login
        echo "$name a été ajouté au groupe G_Info_$site2"

    }
    elseif ($Uoffice -eq "$site2" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity "G_Compta_$site2" -Members $login
        echo "$name a été ajouté au groupe G_Compta_$site2"

    }


    #********Ajout des users de $site3 dans leurs groupes********************


    if ($Uoffice -eq "$site3" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity "G_Info_$site3" -Members $login
        echo "$name a été ajouté au groupe G_Info_$site3"

    }
    elseif ($Uoffice -eq "$site3" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity "G_Compta_$site3" -Members $login
        echo "$name a été ajouté au groupe G_Compta_$site3"

    }


#********Ajout des users de $site1 dans leurs groupes********************


    if ($Uoffice -eq "$site1" -and $dept -eq "Info"){

        Add-ADGroupMember -Identity "G_Info_$site1" -Members $login
        echo "$name a été ajouté au groupe G_Info_$site1"

    }
    elseif ($Uoffice -eq "$site1" -and $dept -eq "Compta"){

        Add-ADGroupMember -Identity "G_Compta_$site1" -Members $login
        echo "$name a été ajouté au groupe G_Compta_$site1"

    }

} #Accolade fermante de notre boucle – Fin de la boucle

Add-ADGroupMember -Identity 'G_Info_InterSite' -Members G_Info_$site1,G_Info_$site2,G_Info_$site3
Add-ADGroupMember -Identity 'G_Compta_InterSite' -Members G_Compta_$site1,G_Compta_$site2,G_Compta_$site3