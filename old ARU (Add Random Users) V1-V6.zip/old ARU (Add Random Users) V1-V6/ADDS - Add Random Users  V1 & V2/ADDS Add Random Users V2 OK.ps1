﻿
Import-Module ActiveDirectory
Import-Module 'Microsoft.PowerShell.Security'

$users = Import-Csv -Delimiter ";" -Path "users-random.csv"


$netbios=Read-Host "Entrez votre NetBIOS"
$domain=Read-Host "Entrez votre nom de domaine"
$rep=Read-Host "Utiliser l'ou - utilisateurs -  par défaut (que le script créer automatiquement) [O/N]?"

If ($rep -eq ’O’) 
{ 
    $defaultOU="utilisateurs"
    New-ADOrganizationalUnit -Name $defaultOU -Path "DC=$netbios,DC=$domain"
    $ou1=$defaultOU
}
Else 
{
    $root=Read-Host "Nom de la racine de votre Arbre LDAP : "
    New-ADOrganizationalUnit -Name $root -Path "DC=$netbios,DC=$domain"
    $ou1=$root
}

#*******Ajout de chaque utilisateur dans son OU spécifique*******

foreach ($user in $users){
    
    $name = $user.firstName + " " + $user.lastName
    $fname = $user.firstName
    $lname = $user.lastName
    $login = $user.firstName + "." + $user.lastName
    $Uoffice = $user.office
    $Upassword = $user.password
    $dept = $user.department
  

    switch($user.office){
        "Paris" {$office = "OU=$ou1,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 
        "Berlin" {$office = "OU=$ou1,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 
        "Londres" {$office = "OU=$ou1,DC=$netbios,DC=$domain"} # à modifier, pour adpater à sa sauce 
        # default {$office = "OU=Users,DC=$netbios,DC=$domain"}    
    }
    
     try {
            New-ADUser -Name $name -SamAccountName $login -UserPrincipalName $login -DisplayName $name -GivenName $fname -Surname $lname -AccountPassword (ConvertTo-SecureString $Upassword -AsPlainText -Force) -City $Uoffice -Path $office -Department $dept -Enabled $true
            echo "Utilisateur ajouté : $name"
          
           
        } catch{
            echo "utilisateur non ajouté : $name"
       }   

}